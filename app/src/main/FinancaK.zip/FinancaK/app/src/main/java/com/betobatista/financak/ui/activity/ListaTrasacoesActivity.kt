package com.betobatista.financak.ui.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.betobatista.financak.R

class ListaTrasacoesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_transacoes);
    }

}